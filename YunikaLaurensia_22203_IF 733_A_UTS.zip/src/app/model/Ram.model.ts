import { Item } from './Item.model';

export interface Ram extends Item {
    speed: number;
    size: string;
}