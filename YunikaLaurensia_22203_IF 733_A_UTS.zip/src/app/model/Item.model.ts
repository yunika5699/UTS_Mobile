export interface Item {
    id: number,
    photo: string,
    name: string,
    brand: string,
    price: number,
    stock: number,
    type: string
}