import { Item } from './Item.model';

export interface Gpu extends Item {
    
}